package com.example.camerademoapp;

import android.content.Context;
import android.content.Intent;
import android.hardware.Camera;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Camera camera;
    FrameLayout frameLayout;
    Holder showCamera;


    Button stopCam;
    Button startCam;
    Button wifiSpeed;
    Button go;


    public int getWifiLevel() {
        WifiManager wifiManager = (WifiManager) this.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        int linkSpeed = wifiManager.getConnectionInfo().getRssi();
        int level = WifiManager.calculateSignalLevel(linkSpeed, 5);
        return level;
    }

    public int getDownSpeed() {
        int downSpeed = 0;
        ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(CONNECTIVITY_SERVICE);
        NetworkCapabilities nc = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                nc = connectivityManager.getNetworkCapabilities(connectivityManager.getActiveNetwork());
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
            downSpeed = nc.getLinkDownstreamBandwidthKbps();

        return downSpeed;
    }

    public int getUpSpeed(){
        int upSpeed = 0;

        ConnectivityManager connectivityManager = (ConnectivityManager)this.getSystemService(CONNECTIVITY_SERVICE);
        NetworkCapabilities nc = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                nc = connectivityManager.getNetworkCapabilities(connectivityManager.getActiveNetwork());
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            upSpeed = nc.getLinkUpstreamBandwidthKbps();

        }

        return upSpeed;
    }


    public int getSignal(){
        int signal = 0;
        ConnectivityManager connectivityManager = (ConnectivityManager)this.getSystemService(CONNECTIVITY_SERVICE);
        NetworkCapabilities nc = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                nc = connectivityManager.getNetworkCapabilities(connectivityManager.getActiveNetwork());
            }
        }


            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                signal = nc.getSignalStrength();
            }

        return signal;
    }





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);





        int downSpeed = 0;
        int upSpeed = 0;

        ConnectivityManager connectivityManager = (ConnectivityManager)this.getSystemService(CONNECTIVITY_SERVICE);
        NetworkCapabilities nc = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                nc = connectivityManager.getNetworkCapabilities(connectivityManager.getActiveNetwork());
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            downSpeed = ((NetworkCapabilities) nc).getLinkDownstreamBandwidthKbps();
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            upSpeed = nc.getLinkUpstreamBandwidthKbps();
        }


        Context mContext = this;

        frameLayout = (FrameLayout) findViewById(R.id.frameLayout);

        camera = Camera.open();

        showCamera = new Holder( mContext, camera);
        frameLayout.addView(showCamera);


        startCam =(Button) findViewById(R.id.startCam);

        startCam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                camera = Camera.open();
                showCamera = new Holder( mContext, camera);
                frameLayout.addView(showCamera);


            }
        });



        stopCam = (Button) findViewById(R.id.stopCam);

        stopCam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                camera.stopPreview();
                camera.release();
                frameLayout.removeAllViews();
            }
        });


        wifiSpeed = (Button) findViewById(R.id.wifiSpeed);


       // int finalDownSpeed = downSpeed;
        wifiSpeed.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View v) {

               // int wifiLevel = getWifiLevel();
                int Dspeed = getDownSpeed();
                int USpeed = getUpSpeed();
                int signal = getSignal();
                String outputMessage = "D: " + String.valueOf(Dspeed);
                outputMessage += " U:" + String.valueOf(USpeed);
                outputMessage += " S: " + String.valueOf(signal);


                Toast toast=Toast.makeText(getApplicationContext(), outputMessage, Toast.LENGTH_SHORT);
                toast.setMargin(50,50);
                toast.show();

            }
        });


        go = (Button) findViewById(R.id.internetButton);
        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Fast.class);
                startActivity(intent);
            }
        });



    }






}