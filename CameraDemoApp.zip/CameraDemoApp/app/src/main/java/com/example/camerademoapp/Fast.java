package com.example.camerademoapp;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;

public class Fast extends AppCompatActivity {

    WebView wv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fast);

        wv = (WebView) findViewById(R.id.web);
        wv.setWebViewClient(new WebViewClient());
        wv.loadUrl("https://fast.com/tr/");

    }
}